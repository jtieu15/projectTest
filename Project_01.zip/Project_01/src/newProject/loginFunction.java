package newProject;



import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class loginFunction {

	public static void main(String[] args) throws Throwable {

		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver-win64\\chromedriver.exe"); 

		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		//open buggy car website
		driver.get("https://buggy.justtestit.org/");
		
		//click Register button
		WebElement register = driver.findElement(By.xpath("//a[normalize-space()='Register']"));
		register.isDisplayed();
		register.isEnabled();
		register.click();
		
		//filling out the register details
		WebElement username = driver.findElement(By.id("username"));
		username.isDisplayed();
		username.isEnabled();
		username.sendKeys("JourneyUserTest00");

		WebElement firstName = driver.findElement(By.id("firstName"));
		firstName.isDisplayed();
		firstName.isEnabled();
		firstName.sendKeys("firstTest");

		WebElement lastName = driver.findElement(By.id("lastName"));
		lastName.isDisplayed();
		lastName.isEnabled();
		lastName.sendKeys("lastTest");

		WebElement password = driver.findElement(By.id("password"));
		password.isDisplayed();
		password.isEnabled();
		password.sendKeys("Password123@");

		WebElement confirmPassword = driver.findElement(By.id("confirmPassword"));
		confirmPassword.isDisplayed();
		confirmPassword.isEnabled();
		confirmPassword.sendKeys("Password123@");
		
		//clicks register after filling out the information 
		WebElement clickRegBtn = driver.findElement(By.xpath("//button[normalize-space()='Register']"));
		clickRegBtn.isDisplayed();
		clickRegBtn.isEnabled();
		clickRegBtn.click();
		
		//enter login user 
		WebElement login = driver.findElement(By.xpath("//input[@placeholder='Login']"));
		login.isDisplayed();
		login.isEnabled();
		login.sendKeys("JourneyUserTest00");
		
		//enter password 
		WebElement passwordLogin = driver.findElement(By.xpath("//input[@name='password']"));
		passwordLogin.isDisplayed();
		passwordLogin.isEnabled();
		passwordLogin.sendKeys("Password123@");
		
		//click login button 
		WebElement clickLogin = driver.findElement(By.xpath("//button[normalize-space()='Login']"));
		clickLogin.isDisplayed();
		clickLogin.isEnabled();
		clickLogin.sendKeys(Keys.RETURN);
		Thread.sleep(5000);
		
		//verifying user successfully login 
		WebElement verifyLogin = driver.findElement(By.xpath("//span[@class='nav-link disabled']"));
		String ActualValue = verifyLogin.getText();
		String ExpectedValue = "Hi, firstTest";

		if (ActualValue == ExpectedValue) {
			System.out.println("Failed! Register user did not login");
		} else

			System.out.println("Success! Register user login");
	}
}
